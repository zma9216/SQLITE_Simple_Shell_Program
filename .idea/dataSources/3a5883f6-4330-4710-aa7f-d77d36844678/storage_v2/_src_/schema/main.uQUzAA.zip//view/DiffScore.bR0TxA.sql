CREATE VIEW DiffScore (avg_paper, avg_area, diff, paper_id) AS
    SELECT Q2.avg_area, Q3.avg_paper,
    abs(Q3.avg_paper - Q2.avg_area), p1.id
    FROM papers p1,
    (SELECT AVG(r2.overall) AS avg_area, p2.area AS pa
        FROM reviews r2, papers p2
        WHERE r2.paper = p2.id
        GROUP BY p2.area) Q2,
    (SELECT AVG(r3.overall) AS avg_paper, r3.paper AS rp
        FROM reviews r3
        GROUP BY r3.paper) Q3 
    WHERE p1.id = Q3.rp
    AND p1.area = Q2.pa;

